<?php

namespace ForminatorGoogleAddon\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}